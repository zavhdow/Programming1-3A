import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class button_clicker extends PApplet {

Button clickster = new Button(50, 50, 100, 75);


public void setup() {
  size(200, 200);
}


public void draw() {
  background(255);
  stroke(0);
  clickster.click();
}

class Button {
  float buttonX = 50;
  float buttonY = 50;
  float buttonW = 100;
  float buttonH = 75;
  boolean on;
  
  //constructor for all variables
  Button(float tempX, float tempY, float tempW, float tempH) {
    buttonX  = tempX;
    buttonY  = tempY;
    buttonW  = tempW;
    buttonH  = tempH;
    on = false;
  }
  
  public void click() {
    if (mouseX >= buttonX && mouseX <= buttonX + buttonW && mouseY >= buttonY && mouseY <= buttonY + buttonH) {
      if (mousePressed == true) {
        fill(0xffFF0900);
        on = true;
      } else {
        fill(0xff007DFF);
      }
    } else {
      fill(0xff001BFF);
    }
  rect(buttonX, buttonY, buttonW, buttonH);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "button_clicker" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
