import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Grid extends PApplet {

/* Some credit to Mr.Kapptie at Skyline High 
...
...
...
Okay, pretty much all credit to Mr. Kapptie*/
public void setup() {
  size(1000, 1000);
  background(0xff000666);
  smooth();
}

public void draw() {
  background(0xff666999);
  drawGrid(100);
}


public void drawGrid(int spacing){
  //set min, set max, set incrementer
  for (int i=spacing; i<10000; i+=spacing) {
    fill(0);
    line(0, i, width, i);
    line(i, 0, i, height);
    textSize(8);
    fill(150);
    text(i, 5, i);
    text(i, i-10, 10);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Grid" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
