import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Lightspeed_unit_converter extends PApplet {

int c = 299792458;
float theMouseX;

public void setup(){
  size(1100, 250);
}


public void draw(){
  background(190);
  mouseValue();
  
  //title
  fill(0xffFFFF00);
  textSize(30);
  textAlign(CENTER);
  text("Time dialation converter", width/2, 30);
  textSize(20);
  text("By ZAVHDOW", width/2, 50);
  textSize(15);
  fill(0xffFFFFFF);
  text("Move your cursor to change values", width/2, 80);
  text("Move slowly to get more precise values", width/2, 95);
  
  //gauges
  textSize(20);
  textAlign(LEFT);
  fill(0);
  text("%C: " + (theMouseX), 10, 20);
  text("m/s: " + convertPerCtoMps(theMouseX), 10, 40);
  text("mph: " + convertMpstoMph(convertPerCtoMps(theMouseX)), 10, 60);
  text("Time dialation: " + convertPerCtoPerDial(theMouseX), 10, 80);
  textSize(10);
  
  //indicator line
  strokeWeight(1);
  stroke(0xffFF0000);
  line(theMouseX*1000+25, 0, theMouseX*1000+25, height);
  
  //%C line
  strokeWeight(2);
  stroke(0);
  line(25, 115, 1025, 115);
  fill(0xffF011F5);
  text("Percent of the speed of light (%C)", 30, 110);
  for (int i=0; i <= 100; i += 10) {
    tickMark((i*10)+25, 115, i + "%");
  }
  
  //m/s line
  strokeWeight(2);
  stroke(0);
  line(25, 150, 1025, 150);
  fill(0xffF011F5);
  text("Meters per second (m/s)", 30, 145);
  for (int i=0; i <= c; i += 50000000) {
    tickMark( (convertMpstoPerC(i)*1000)+25, 150, i + "");
  }
  tickMark(1025, 150, c + "");
  
  //mph line
  strokeWeight(2);
  stroke(0);
  line(25, 185, 1025, 185);
  fill(0xffF011F5);
  text("Miles per hour (mph)", 30, 180);
  for (int i=0; i <= convertMpstoMph(c); i += 100000000) {
    tickMark( ((convertMpstoPerC(i)*1000)/2.237f)+25, 185, i + "");
  }
  tickMark(1025, 185, "670616629");
  
  //time dialation line
  strokeWeight(2);
  stroke(0);
  line(25, 220, 1025, 220);
  fill(0xffF011F5);
  text("Years passed on stationary object (earth) if you spent one year at this speed (Time dialation)", 30, 215);
  tickMark(25, 220, "1.0");
  tickMark((.6f*1000)+25 , 220, "1.25");
  tickMark((.75f*1000)+25 , 220, "1.5");
  tickMark((.866f*1000)+25 , 220, "2");
  tickMark((.943f*1000)+25 , 220, "3");
  tickMark((.968f*1000)+25 , 220, "4");
  tickMark((.98f*1000)+25 , 220, "5");
  tickMark(1025, 220, "Infinity");
}


public void mouseValue () {
  if (mouseX >= 25 && mouseX <= 1025) {
    theMouseX = (mouseX - 25) / 1000.0f;
  }
}


public void tickMark(float xpos, int liney, String texxt){
  stroke(0);
  line(xpos, liney-10, xpos, liney+10);
  fill(0xffFF0000);
  textSize(10);
  text(texxt, xpos+2, liney+10);
}


public float convertMpstoPerC (float mps) {
  mps = mps / c;
  return mps;
}


public float convertPerCtoMps (float perC) {
  perC *= c;
  return perC;
}


public float convertPerCtoPerDial (float perC) {
  perC = 1 / sqrt(1 - (pow(convertPerCtoMps(perC), 2) / pow(c, 2)));
  return perC;
}


public float convertMpstoMph (float Mps) {
  Mps *= 2.237f;
  return Mps;
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Lightspeed_unit_converter" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
